﻿<#
.SYNOPSIS
Get-NetRoutes.ps1
Returns Get-NetRoute data
.NOTES
Next line tells Kansa.ps1 how to format this script's output
OUTPUT tsv
#>
Get-NetRoute